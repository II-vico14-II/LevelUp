<template>
    <div> Memory </div>
  
</template>

<script>
export default {
    name : 'MemoryTrain'

}
</script>

<style>

</style>