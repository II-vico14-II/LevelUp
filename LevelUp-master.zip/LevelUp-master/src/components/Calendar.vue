<template>
  <div class="text-center section">
    <h2 class = "titre">Calendar</h2>
    <p class="text-lg font-medium text-gray-600 mb-6">
      Planifiez vos activités
    </p>
    <calendar
      class="custom-calendar max-w-full"
      :masks="masks"
      :attributes="attributes"
      disable-page-swipe
      is-expanded
    >
      <template v-slot:day-content="{ day, attributes }">
        <div class="flex flex-col h-full z-10 overflow-hidden">
          <span class="day-label text-sm text-gray-900">{{ day.day }}</span>
          <div class="flex-grow overflow-y-auto overflow-x-auto">
            <p
              v-for="attr in attributes"
              class="text-xs leading-tight rounded-sm p-1 mt-0 mb-1"
              :class="attr.customData.class"
              v-bind:key="attr.value"
            >
              {{ attr.customData.title }}

            </p>
          </div>
        </div>
      </template>
    </calendar>
    <div class="form">
      <form>

        <div class="form-group">
          <label for="eventName">Evènement à ajouter </label>
          <input v-model="Event" type="text" class="form-control" id="eventName" aria-describedby="event" placeholder="Nouvel évènement">
        </div>

        <div class="timeEventForm">

        <div>
          <label for="yearEvent">Jour</label>
          <select class="custom-select" v-model="day" id="dayEvent">
            <option selected >Jour</option>
            <option value="2">1</option>
            <option value="1">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
            <option value="16">16</option>
            <option value="17">17</option>
            <option value="18">18</option>
            <option value="19">19</option>
            <option value="20">20</option>
            <option value="21">21</option>
            <option value="22">22</option>
            <option value="23">23</option>
            <option value="24">24</option>
            <option value="25">25</option>
            <option value="26">26</option>
            <option value="27">27</option>
            <option value="28">28</option>
            <option value="29">29</option>
            <option value="30">30</option>
            <option value="31">31</option>

          </select>
        </div>

        <div>
          <label for="yearEvent">Mois</label>
          <select class="custom-select" v-model="month" id="monthEvent">
            <option selected>Mois</option>
            <option value="0">Janvier</option>
            <option value="1">Février</option>
            <option value="2">Mars</option>
            <option value="3">Avril</option>
            <option value="4">Mai</option>
            <option value="5">Juin</option>
            <option value="6">Juillet</option>
            <option value="7">Août</option>
            <option value="8">Septembre</option>
            <option value="9">Octobre</option>
            <option value="10">Novembre</option>
            <option value="11">Décembre</option>
          </select>
        </div>

        <div>
          <label for="yearEvent">Année</label>
          <select class="custom-select" v-model="year" id="yearEvent">
            <option selected = "2021">Année</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
            <option value="2023">2023</option>
          </select>
        </div>

        <div>
          <label for="categorieEvent">Catégorie</label>
          <select class="custom-select" v-model="categorie" id="categorieEvent">
            <option selected>Catégorie</option>
            <option value=1>Sport</option>
            <option value=2>Travail</option>
            <option value=3>Santé</option>
            <option value=4>Autre</option>
          </select>
        </div>

        </div>

        <button @click="addToCalendar(Event, year, month, day, categorie)" class="btn btn-primary" id="addEventButton">Ajouter</button>

      </form>
    </div>
  </div>
</template>

<script>
import Calendar from 'v-calendar/lib/components/calendar.umd'
export default {
  components: {
    Calendar
  },
  data() {
    return {
      key: 1,
      Event: '',
      year: '',
      month: '',
      day: '',
      categorie: '',
      masks: {
        weekdays: 'WWW',
      },
      attributes: []
    };
  },
  methods :{
    addToCalendar: function (title, years, month, day, categorie){
      let date = new Date(years, month, day)
      if (categorie == 3)
      {
        let newEvent = {key: this.key, customData:{title: title, class: 'sante'}, dates: date}
        this.attributes.push(newEvent)
        this.key++
      }
      else if (categorie == 2 )
      {
        let newEvent = {key: this.key, customData:{title: title, class: 'travail'}, dates: date}
        this.attributes.push(newEvent)
        this.key++
      }
      else if (categorie == 1 )
      {
        let newEvent = {key: this.key, customData:{title: title, class: 'sport'}, dates: date}
        this.attributes.push(newEvent)
        this.key++
      }
      else 
      {
        let newEvent = {key: this.key, customData:{title: title, class: 'autre'}, dates: date}
        this.attributes.push(newEvent)
        this.key++
      }
      
      
    }
  }
};
</script>


<style lang="postcss" scoped>

.form{
  width: 50%;
  height: 25%;
  margin: 30px auto;
}


.timeEventForm{
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-around;
}

#addEventButton{
  margin: 15px;
}

::-webkit-scrollbar {
  width: 0px;
}
::-webkit-scrollbar-track {
  display: none;
}
/deep/ .custom-calendar.vc-container {
  --day-border: 1px solid #b8c2cc;
  --day-border-highlight: 1px solid #b8c2cc;
  --day-width: 90px;
  --day-height: 90px;
  --weekday-bg: #f8fafc;
  --weekday-border: 1px solid #eaeaea;
  border-radius: 0;
  width: 100%;

  & .vc-header {
    background-color: #eaeaea;
    padding: 10px 0;
  }
  & .vc-weeks {
    padding: 0;
  }
  & .vc-weekday {
    background-color: var(--weekday-bg);
    border-bottom: var(--weekday-border);
    border-top: var(--weekday-border);
    padding: 5px 0;
  }
  & .vc-day {
    padding: 0 5px 3px 5px;
    text-align: left;
    height: var(--day-height);
    min-width: var(--day-width);
    background-color: white;
    &.weekday-1,
    &.weekday-7 {
      background-color: #eff8ff;
    }
    &:not(.on-bottom) {
      border-bottom: var(--day-border);
      &.weekday-1 {
        border-bottom: var(--day-border-highlight);
      }
    }
    &:not(.on-right) {
      border-right: var(--day-border);
    }
  }
  & .vc-day-dots {
    margin-bottom: 5px;
  }
}

body {
  background-color: #FEFED3;
}

/deep/ .text-lg
{
  font-size: 20px;
  color: white;
  font-weight: 600;
}

.titre
{
  color: white;
}

/deep/ .vc-day
{
  color: black;
  border: solid rgb(170, 167, 167, 0.5) 0.7px;
  border-highlight: 1px solid #b8c2cc;
  padding: 2px;
}

/deep/ .vc-weekday
{
  font-size: 15px;
}

/deep/ .custom-calendar.vc-container
{
    border-radius: 12px;
    border: solid rgba(131, 130, 130, 0.5) 1.5px;
    padding: 1%;
}

/deep/ .text-center section
{
  margin-left: 10%;
  margin-right: 10%;
}

/* Evenements */
.sport
{
  color: white;
  background-color: rgba(255, 0, 0, 0.76);
  border-radius: 5px;
}

.travail
{
  color: white;
  background-color: rgb(53, 50, 228);
  border-radius: 5px;
}

.sante 
{
  color: white;
  background-color: rgb(43, 223, 82);
  border-radius: 5px;
}

.autre
{
  color: white;
  background-color: rgba(255, 145, 0, 0.863);
  border-radius: 5px;
}

label
{
  font-size: 18px;
  font-weight: bolder;
  color: white;
}


</style>