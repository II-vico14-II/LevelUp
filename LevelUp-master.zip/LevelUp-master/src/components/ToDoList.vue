
<template>
  <div id="app" class="container">
    <h1 class = "titre">Choses à faire !</h1>

    <div v-if="!isEditing">
      <div class="input-group mb-3">
        <input
          type="text"
          class="form-control"
          placeholder="Tache"
          aria-label="Task"
          aria-describedby="basic-addon2"
          v-model="task.todo"
        />
        <div class="input-group-append">
          <button class="btn btn-primary" @click="storeTodo" type="button">
            Ajouter
          </button>
        </div>
      </div>
      <div>
        <label> Date </label>
        <date-picker v-model="task.date" lang="fr" type="datetime" format="DD-MM-YYYY"> </date-picker>
      </div>
    </div>
    <div v-else>
      <div class="input-group mb-3">
        <input
            type="text"
            class="form-control"
            placeholder="Update"
            aria-label="Update"
            aria-describedby="basic-addon2"
            v-model="task.todo"
        />
        <div class="input-group-append">
          <button class="btn btn-primary" @click="updateTask" type="button">
            Actualiser
          </button>
        </div>
      </div>
      <label> Date </label>
      <date-picker v-model="task.date" lang="fr" type="datetime" format="DD-MM-YYYY"> </date-picker>
    </div>
    <div class="list">
      <ul class="list-group">
        <li v-for="(task, index) in tasks" :key="task.key" class="list-group-item">
          <div class="toDoListContainer">
            <div class="toDoListMessage">
              <p> <Span STYLE="text-decoration: underline"> Pour le </Span> : {{ getDateDuJour(task.date) }} <br><br> 
              <Span STYLE="text-decoration: underline">Tâche à réaliser </Span> :  {{ task.todo }}</p>
            </div>
            <div class="toDoListOption">
              <button
                type="button"
                @click="editTask(index)"
                class="btn btn-success"
              >
                Modifier
              </button>
              <button
                type="button"
                @click="removeTask(index)"
                class="btn btn-danger"
              >
                Effacer
              </button>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import DatePicker from 'vue2-datepicker'
import 'vue2-datepicker/index.css'
export default {
  name: 'App',
    components: {
        DatePicker
    },
  data() {
    return {
      isEditing: false,
      editingIndex: 0,
      key: 0,
      task: {
        key: 1,
        todo: '',
        date: ''
      },
      tasks: [],
      time: "",
      selectedTodo: null,
    };
  },

  methods: {
    storeTodo() {
      if(this.task.todo != '' && this.task.date != ''){
        let formatedDate = this.task.date.toString().slice(0, 15)
        this.tasks.push({key: this.key++, todo: this.task.todo, date: formatedDate})
        this.key++
      }
      else{
        alert("Veuillez entrez des données correctes")
      }
    },

    removeTask(index) {
      this.tasks.splice(index, 1)
    },

    updateTask() {
      if(this.task.todo !== '' && this.task.date !== ''){
        let formatedDate = this.task.date.toString().slice(0, 15)
        this.tasks.splice(parseInt(this.editingIndex, 10), 1, {key: this.key++, todo: this.task.todo, date: formatedDate})
        this.isEditing = false
      }
      else{
        alert("Veuillez entrez des données correctes")
      }
    },

    editTask(index) {
      this.isEditing = true
      this.editingIndex = parseInt(index, 10)
      this.key++
    },
    getDateDuJour(date){

      const newdate = new Date(date);
      let jour = newdate.getDay();
      const mois = newdate.getMonth() + 1 ;

      const JoursDeLaSemaine = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi','Jeudi', 'Vendredi', 'Samedi']
      const MoisDeLanne = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']

      const jourl = JoursDeLaSemaine[jour];
      const journum = newdate.getDate();
      const moisl = MoisDeLanne[mois];
      const annee = newdate.getYear() + 1900;

      let nvdate = ( jourl + ' ' + journum + ' ' + moisl + ' ' + annee);
      return (nvdate);
    }
  },
};
</script>



<style scoped>

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@900&display=swap');

* {
  font-family: 'Poppins', Arial;
}

.toDoListContainer{
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}

.container {
  max-width: 960px;
  margin-top: auto;
}

.list-group-item
{
  margin: 10px;
  border-radius: 4px;
}
h1 {
  padding-top: 40px;
  margin: 20px;
}
.list {
  margin: 10%;
}

label
{
  font-size: 18px;
  margin: 10px;
  color: white;
}

.titre 
{
  color: white;
}
</style>
