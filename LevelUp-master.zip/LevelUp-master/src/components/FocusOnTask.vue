<template>
    <div> Focus </div>
  
</template>

<script>
export default {
    name : 'FocusOnTask'

}
</script>

<style>

</style>