<template>
  <div id="app">
    <div class="container">
            <nav>
                  <input type="checkbox" id="nav" class="hidden">
                  <label for="nav" class="nav-btn">
                        <i></i>
                        <i></i>
                        <i></i>
                  </label>
                  <div class="logo">
                        <router-link :to="{ path: '/'} "><a >Level UP</a> </router-link>
                  </div>
                  <div class="nav-wrapper">
                        <ul>
                              <li><router-link :to="{ path: '/'} "><a >Calendar</a> </router-link></li>
                              <li><router-link :to="{ path: '/ToDoList'} "><a >ToDo List</a> </router-link></li>
                              <li><router-link :to="{ path: '/MemoryTrain'} "> <a >Memory Train</a> </router-link></li>
                              <li><router-link :to="{ path: '/FocusOnTask'} "> <a>Focus On Task</a> </router-link></li>
                        </ul>
                  </div>
            </nav>
      </div>

      
    
    <router-view> </router-view>
  </div> 
</template>

<script>
import Calendar from './components/Calendar.vue'
import Vue from 'vue';
import VueRouter from 'vue-router';
/*import routes from 'main.js'*/

Vue.use(VueRouter);


import ToDoList from './components/ToDoList.vue'
import FocusOnTask from './components/FocusOnTask.vue'
import MemoryTrain from './components/MemoryTrain.vue'


const routes = [
  { path: '/ToDoList', component: ToDoList },
  { path: '/FocusOnTask', component: FocusOnTask },
  { path: '/MemoryTrain', component: MemoryTrain },
  { path: '/', component: Calendar }
]

const router = new VueRouter({
      routes : routes
})


export default {
  router,
  name: 'App',
  components: {
    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 10px;
}

/* Page */

* {
      box-sizing: border-box;
      font-family: 'Poppins', Arial;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@900&display=swap');


html {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100vh;
}

body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100vh;
      font-family: Poppins;
      font-weight: 400;
      color: white;


      /*background: rgb(6,0,108);
      background: 
        linear-gradient(217deg, rgb(0, 255, 128), rgba(255,0,0,0) 70.71%),
        linear-gradient(127deg, rgba(0, 255, 42, 0.8), rgba(0,255,0,0) 70.71%),
        linear-gradient(336deg, rgba(179, 255, 0, 0.8), rgba(0,0,255,0) 70.71%);*/

      background-image: linear-gradient(to right top, #1c1955, #2d2d7c, #3d43a5, #4b5bd1, #5774ff);


      background-position: center;
      background-size: cover;
      background-attachment: fixed;

      /*linear-gradient(90deg, rgba(6,0,108,1) 0%, rgba(108,14,201,1) 48%, rgba(0,212,255,1) 100%);*/
}

nav {
      padding: 8px;
}

.logo {
      float: left;
      padding: 8px;
      margin-left: 16px;
      margin-top: 8px;
}

.logo a {
     color: #8b9eb3;
      text-transform: uppercase;
      font-weight: 700;
      font-size: 18px;
      letter-spacing: 0px;
      text-decoration: none;
}

nav ul {
      float: right;
}

nav ul li {
      display: inline-block;
      float: left;
}

nav ul li:not(:first-child) {
      margin-left: 48px;
}

nav ul li:last-child {
      margin-right: 24px;
}

nav ul li a {
      display: inline-block;
      outline: none;
      color: #8b9eb3;
      text-transform: uppercase;
      text-decoration: none;
      font-size: 14px;
      letter-spacing: 1.2px;
      font-weight: 600;
}

@media screen and (max-width: 864px) {
      .logo {
            padding: 0;
      }

      .nav-wrapper {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;

            background:white;
            opacity: 0;
            transition: all 0.2s ease;
      }

      .nav-wrapper ul {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 100%;
      }

      .nav-wrapper ul li {
            display: block;
            float: none;
            width: 100%;
            text-align: right;
            margin-bottom: 10px;
      }

      .nav-wrapper ul li:nth-child(1) a {
            transition-delay: 0.2s;
      }

      .nav-wrapper ul li:nth-child(2) a {
            transition-delay: 0.3s;
      }

      .nav-wrapper ul li:nth-child(3) a {
            transition-delay: 0.4s;
      }

      .nav-wrapper ul li:nth-child(4) a {
            transition-delay: 0.5s;
      }

      .nav-wrapper ul li:nth-child(5) a {
            transition-delay: 0.6s;
      }

      .nav-wrapper ul li:not(:first-child) {
            margin-left: 0;
      }

      .nav-wrapper ul li a {
            padding: 10px 24px;
            opacity: 0;
            color: #000;
            font-size: 14px;
            font-weight: 600;
            letter-spacing: 1.2px;
            transform: translateX(-20px);
            transition: all 0.2s ease;
      }

      .nav-btn {
            position: fixed;
            right: 10px;
            top: 10px;
            display: block;
            width: 48px;
            height: 48px;
            cursor: pointer;
            z-index: 9999;
            border-radius: 50%;
      }

      .nav-btn i {
            display: block;
            width: 20px;
            height: 2px;
            background: #000;
            border-radius: 2px;
            margin-left: 14px;
      }

      .nav-btn i:nth-child(1) {
            margin-top: 16px;
      }

      .nav-btn i:nth-child(2) {
            margin-top: 4px;
            opacity: 1;
      }

      .nav-btn i:nth-child(3) {
            margin-top: 4px;
      }
}

#nav:checked + .nav-btn {
      transform: rotate(45deg);
}

#nav:checked + .nav-btn i {
      background: #000;
      transition: transform 0.2s ease;
}

#nav:checked + .nav-btn i:nth-child(1) {
      transform: translateY(6px) rotate(180deg);
}

#nav:checked + .nav-btn i:nth-child(2) {
      opacity: 0;
}

#nav:checked + .nav-btn i:nth-child(3) {
      transform: translateY(-6px) rotate(90deg);
}

#nav:checked ~ .nav-wrapper {
      z-index: 9990;
      opacity: 1;
}

#nav:checked ~ .nav-wrapper ul li a {
      opacity: 1;
      transform: translateX(0);
}

.hidden {
      display: none;
}

/* Fin MENU */

</style> 
